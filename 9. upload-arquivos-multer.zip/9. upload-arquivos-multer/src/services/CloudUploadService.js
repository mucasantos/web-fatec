require('dotenv').config();
const cloudinary = require('cloudinary').v2;

// Configuração do provedor de nuvem (Cloudinary)
cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME || '',
    api_key: process.env.CLOUDINARY_API_KEY || '',
    api_secret: process.env.CLOUDINARY_API_SECRET || ''
});

class CloudUploadService {
    async uploadFromBuffer(fileBuffer, originalName, folder = 'alunos_fotos') {
        const isConfigured = Boolean(
            process.env.CLOUDINARY_CLOUD_NAME &&
            process.env.CLOUDINARY_API_KEY &&
            process.env.CLOUDINARY_API_SECRET
        );

        // Se o aluno configurou o Cloudinary no .env, faz o upload real via Stream
        if (isConfigured) {
            return new Promise((resolve, reject) => {
                const uploadStream = cloudinary.uploader.upload_stream(
                    {
                        folder: folder,
                        resource_type: 'auto'
                    },
                    (error, result) => {
                        if (error) return reject(error);
                        resolve({
                            provedor: 'CLOUDINARY_REAL',
                            url: result.secure_url,
                            publicId: result.public_id,
                            formato: result.format,
                            bytes: result.bytes
                        });
                    }
                );

                uploadStream.end(fileBuffer);
            });
        }

        // Simulação elegante para ambiente de aula sem obrigar cadastro prévio no Cloudinary
        console.log(`[CloudUploadService] Simulando upload em nuvem para o arquivo: ${originalName} (${fileBuffer.length} bytes)`);
        const randomId = Math.random().toString(36).substring(2, 9);
        return {
            provedor: 'NUVEM_SIMULADA',
            url: `https://res.cloudinary.com/escola-demo/image/upload/v1700000000/${folder}/${randomId}_${originalName}`,
            publicId: `${folder}/${randomId}_${originalName}`,
            bytes: fileBuffer.length,
            mensagem: 'Upload simulado com sucesso. Para upload real, preencha as chaves do Cloudinary no .env.'
        };
    }
}

module.exports = new CloudUploadService();
