const express = require('express');
const path = require('path');
const uploadRoutes = require('./routes/upload.routes');

const app = express();

// Middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve arquivos estáticos da pasta public (interface de teste)
app.use(express.static(path.join(__dirname, '..', 'public')));

// Serve arquivos estáticos enviados para a pasta uploads (ex: http://localhost:3000/uploads/foto.png)
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// Rotas da API de Upload
app.use('/api/upload', uploadRoutes);

// Tratamento de erros do Multer e globais
app.use((err, req, res, next) => {
    if (err.name === 'MulterError') {
        if (err.code === 'LIMIT_FILE_SIZE') {
            return res.status(400).json({ erro: 'Arquivo muito grande! O limite máximo permitido é 5MB.' });
        }
        return res.status(400).json({ erro: `Erro no upload: ${err.message}` });
    }

    if (err.message.includes('inválido') || err.message.includes('Permitidos')) {
        return res.status(400).json({ erro: err.message });
    }

    console.error('Erro no servidor:', err);
    return res.status(500).json({ erro: 'Erro interno no processamento do arquivo.' });
});

module.exports = app;
