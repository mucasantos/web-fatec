const multer = require('multer');

// CONFIGURAÇÃO EM MEMÓRIA (Armazena o arquivo no buffer RAM para envio direto à nuvem)
const storage = multer.memoryStorage();

const fileFilter = (req, file, cb) => {
    const tiposPermitidos = ['image/jpeg', 'image/png', 'image/webp'];

    if (tiposPermitidos.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error('Para envio à nuvem, permitidos apenas imagens: JPEG, PNG e WEBP.'), false);
    }
};

const uploadMemory = multer({
    storage,
    fileFilter,
    limits: {
        fileSize: 5 * 1024 * 1024 // 5 MB
    }
});

module.exports = uploadMemory;
