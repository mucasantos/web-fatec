const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

// Garante que o diretório 'uploads' exista
const uploadDir = path.resolve(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// 1. CONFIGURAÇÃO DE DISCO (Salvar no próprio servidor)
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        // Gera um hash aleatório + timestamp para evitar sobreescrita de arquivos com mesmo nome
        const hash = crypto.randomBytes(8).toString('hex');
        const ext = path.extname(file.originalname).toLowerCase();
        const nomeLimpo = path.basename(file.originalname, ext)
            .replace(/[^a-zA-Z0-9]/g, '_')
            .toLowerCase();

        cb(null, `${Date.now()}-${hash}-${nomeLimpo}${ext}`);
    }
});

// 2. FILTRO DE TIPOS DE ARQUIVOS (Segurança)
const fileFilter = (req, file, cb) => {
    const tiposPermitidos = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];

    if (tiposPermitidos.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error('Tipo de arquivo inválido! Permitidos apenas: JPEG, PNG, WEBP e PDF.'), false);
    }
};

// 3. INSTÂNCIA DO MULTER COM LIMITES
const uploadLocal = multer({
    storage,
    fileFilter,
    limits: {
        fileSize: 5 * 1024 * 1024 // Limite de 5 Megabytes
    }
});

module.exports = uploadLocal;
