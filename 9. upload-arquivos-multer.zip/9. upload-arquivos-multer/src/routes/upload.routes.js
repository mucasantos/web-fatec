const express = require('express');
const router = express.Router();
const uploadLocal = require('../config/multerLocal');
const uploadMemory = require('../config/multerMemory');
const uploadController = require('../controllers/UploadController');

// 1. Rota de Upload Local (campo do form: "arquivo")
router.post('/local', uploadLocal.single('arquivo'), (req, res, next) => {
    uploadController.uploadLocal(req, res, next);
});

// 2. Rota de Upload para Nuvem / API Externa (campo do form: "foto")
router.post('/cloud', uploadMemory.single('foto'), (req, res, next) => {
    uploadController.uploadCloud(req, res, next);
});

// 3. Rota de Upload de Múltiplos Arquivos (campo do form: "documentos", max: 5)
router.post('/multiplos', uploadLocal.array('documentos', 5), (req, res, next) => {
    uploadController.uploadMultiplo(req, res, next);
});

module.exports = router;
