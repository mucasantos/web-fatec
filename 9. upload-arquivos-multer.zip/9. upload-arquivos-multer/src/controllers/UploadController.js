const cloudUploadService = require('../services/CloudUploadService');

class UploadController {
    // 1. Upload Local (Salva no disco ./uploads)
    async uploadLocal(req, res, next) {
        try {
            if (!req.file) {
                return res.status(400).json({ erro: 'Nenhum arquivo enviado! Envie o arquivo no campo "arquivo".' });
            }

            // Constrói a URL pública para acessar o arquivo salvo no servidor
            const baseUrl = `${req.protocol}://${req.get('host')}`;
            const fileUrl = `${baseUrl}/uploads/${req.file.filename}`;

            return res.status(201).json({
                mensagem: 'Upload local realizado com sucesso!',
                tipo: 'ARMAZENAMENTO_LOCAL',
                arquivo: {
                    nomeOriginal: req.file.originalname,
                    nomeSalvo: req.file.filename,
                    tamanhoBytes: req.file.size,
                    mimeType: req.file.mimetype,
                    caminhoDisco: req.file.path,
                    urlPublica: fileUrl
                }
            });
        } catch (error) {
            next(error);
        }
    }

    // 2. Upload para Nuvem / API Externa (Cloudinary / S3)
    async uploadCloud(req, res, next) {
        try {
            if (!req.file) {
                return res.status(400).json({ erro: 'Nenhum arquivo enviado! Envie o arquivo no campo "foto".' });
            }

            // Envia o buffer em memória direto para a nuvem
            const resultadoNuvem = await cloudUploadService.uploadFromBuffer(
                req.file.buffer,
                req.file.originalname,
                'alunos_perfil'
            );

            return res.status(201).json({
                mensagem: 'Upload para nuvem realizado com sucesso!',
                tipo: 'ARMAZENAMENTO_NUVEM',
                arquivo: {
                    nomeOriginal: req.file.originalname,
                    tamanhoBytes: req.file.size,
                    mimeType: req.file.mimetype,
                    ...resultadoNuvem
                }
            });
        } catch (error) {
            next(error);
        }
    }

    // 3. Upload de Múltiplos Arquivos (ex: galeria ou documentos)
    async uploadMultiplo(req, res, next) {
        try {
            if (!req.files || req.files.length === 0) {
                return res.status(400).json({ erro: 'Nenhum arquivo enviado! Envie múltiplos arquivos no campo "documentos".' });
            }

            const baseUrl = `${req.protocol}://${req.get('host')}`;
            const arquivosSalvos = req.files.map(file => ({
                nomeOriginal: file.originalname,
                nomeSalvo: file.filename,
                tamanhoBytes: file.size,
                urlPublica: `${baseUrl}/uploads/${file.filename}`
            }));

            return res.status(201).json({
                mensagem: `${req.files.length} arquivos enviados com sucesso!`,
                total: req.files.length,
                arquivos: arquivosSalvos
            });
        } catch (error) {
            next(error);
        }
    }
}

module.exports = new UploadController();
