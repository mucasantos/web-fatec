require('dotenv').config();
const app = require('./src/app');

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`🚀 Servidor de Uploads rodando em http://localhost:${PORT}`);
    console.log(`🖼️ Interface de teste visual: http://localhost:${PORT}`);
    console.log(`📁 Pasta local de uploads: http://localhost:${PORT}/uploads`);
});
