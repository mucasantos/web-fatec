# 📦 9. Upload de Arquivos em Node.js com Multer (Local e Nuvem)

Este projeto demonstra as duas principais estratégias de **Upload de Arquivos** no Node.js com **Express**:
1. **Armazenamento no Próprio Servidor (Disco Local)** via `multer.diskStorage`.
2. **Armazenamento em Nuvem / API Externa (Cloudinary / S3 / Supabase)** via `multer.memoryStorage` + Streams/Buffers.

---

## ⚖️ Comparativo: Upload Local vs Upload em Nuvem

| Critério | 🖥️ Upload Local (Disco) | ☁️ Upload em Nuvem (S3 / Cloudinary) |
|---|---|---|
| **Estratégia do Multer** | `multer.diskStorage()` | `multer.memoryStorage()` |
| **Onde o arquivo fica?** | Na pasta `./uploads` do servidor. | Em um Storage Externo (Bucket S3, Cloudinary). |
| **Vantagens** | Fácil de implementar, custo zero para testes locais. | Escalável, não ocupa o disco do servidor, CDN global rápida. |
| **Desvantagens** | Se o servidor reiniciar ou escalar em múltiplas instâncias, os arquivos não são compartilhados. | Requer configuração de credenciais de API. |

---

## 📂 Estrutura do Projeto

```text
9. upload-arquivos-multer/
├── uploads/                          # Pasta onde os arquivos locais são salvos
├── public/
│   └── index.html                    # Interface web interativa para testar uploads
├── src/
│   ├── config/
│   │   ├── multerLocal.js            # Configuração com diskStorage e filtros
│   │   └── multerMemory.js           # Configuração com memoryStorage (RAM Buffer)
│   ├── services/
│   │   └── CloudUploadService.js     # Envio de buffer para Cloudinary / Cloud
│   ├── controllers/
│   │   └── UploadController.js       # Tratamento de req.file e respostas
│   ├── routes/
│   │   └── upload.routes.js          # Rotas /local, /cloud, /multiplos
│   └── app.js                        # express.static('/uploads') e error handler
├── server.js
├── .env
└── package.json
```

---

## 🛡️ 3 Boas Práticas de Segurança em Uploads

1. **Sanitização do Nome do Arquivo:**
   * Nunca use o nome original enviado pelo usuário (pode conter caracteres perigosos ou sobrescrever arquivos).
   * Geramos nomes com: `${Date.now()}-${hash}-${nomeLimpo}${ext}`.
2. **Filtro de Extensões e MIME Types:**
   * Bloqueamos arquivos executáveis (`.exe`, `.sh`, `.php`, `.js`) permitindo apenas imagens (`image/jpeg`, `image/png`, `image/webp`) e documentos autorizados (`application/pdf`).
3. **Limite de Tamanho:**
   * `limits: { fileSize: 5 * 1024 * 1024 }` (limite de 5MB por arquivo para evitar estouro de memória e ataques de negação de serviço).

---

## ⚡ Como Executar e Testar

1. Inicie a aplicação:
   ```bash
   cd "9. upload-arquivos-multer"
   npm run dev
   ```

2. **Pelo Navegador (Interface Visual com Preview):**
   * Acesse: **`http://localhost:3000`** e selecione um arquivo para ver o upload acontecendo em tempo real.

---

## 🧪 Testando via Terminal (cURL)

### 📌 1. Upload Local (Salva no Servidor)
```bash
curl -X POST http://localhost:3000/api/upload/local \
  -F "arquivo=@/caminho/para/sua_foto.png"
```
*Retorna a URL estática: `http://localhost:3000/uploads/170000-hash-sua_foto.png`.*

### 📌 2. Upload para Nuvem / API Externa
```bash
curl -X POST http://localhost:3000/api/upload/cloud \
  -F "foto=@/caminho/para/sua_foto.png"
```
*Retorna a URL pública segura do provedor de nuvem.*

### 📌 3. Upload de Múltiplos Arquivos
```bash
curl -X POST http://localhost:3000/api/upload/multiplos \
  -F "documentos=@/caminho/para/doc1.pdf" \
  -F "documentos=@/caminho/para/doc2.pdf"
```
