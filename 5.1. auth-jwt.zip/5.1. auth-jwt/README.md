# 🔐 5.1. Autenticação JWT com Sequelize ORM (Camadas Simples / MVC)

Este módulo foi desenhado com foco puramente pedagógico: ensinar **Sequelize ORM** e **Autenticação com Token JWT** sem o excesso de camadas da Clean Architecture (sem *Use Cases*, sem *Entities* POJO e sem *Repositories*).

---

## 🎯 Por que este módulo existe?

| Característica | Módulo 5 (Clean Arch) | Módulo 5.1 (Camadas Simples) |
|---|---|---|
| **Arquitetura** | Clean Architecture Completa | MVC Simples / Camadas Diretas |
| **Camadas** | 6 (Routes, Controllers, UseCases, Entities, Repositories, Models) | **3 Principais** (Routes, Controllers, Models) + Middlewares |
| **Onde fica a regra?** | Em arquivos isolados de Use Cases e Entities | Diretamente nos **Controllers** |
| **Quem chama o Sequelize?** | Apenas os Repositories | O **próprio Controller** |
| **Foco de aprendizado** | Arquitetura corporativa e desacoplamento | **Entender o ORM e o fluxo do JWT na prática** |

---

## 📂 Estrutura do Projeto

```text
5.1. auth-jwt/
├── src/
│   ├── config/
│   │   ├── auth.js               # Chave secreta e expiração do JWT
│   │   └── database.js           # Conexão do Sequelize com MySQL
│   ├── models/                   # [CAMADA 1: ORM / BANCO]
│   │   ├── Usuario.js            # Tabela 'usuarios' (nome, email, senha, role)
│   │   ├── Curso.js              # Tabela 'cursos'
│   │   ├── Aluno.js              # Tabela 'alunos'
│   │   └── index.js              # Associações (1 Curso tem muitos Alunos)
│   ├── middlewares/              # [CAMADA 2: INTERCEPTADORES]
│   │   └── auth.middleware.js    # Verifica o Token JWT e permissões de perfil (roles)
│   ├── controllers/              # [CAMADA 3: REGRAS & RESPOSTAS HTTP]
│   │   ├── AuthController.js     # Registro (bcrypt), Login (JWT) e sessão atual (/me)
│   │   └── AlunoController.js    # CRUD de alunos chamando o Sequelize diretamente
│   ├── routes/                   # [CAMADA 4: ROTAS EXPRESS]
│   │   ├── auth.routes.js        # /api/auth/register, /api/auth/login, /api/auth/me
│   │   ├── alunos.routes.js      # Rotas de alunos protegidas por Token
│   │   └── index.js              # Agrupador de rotas
│   └── app.js                    # Express e middlewares globais
├── seeds.js                      # Popula banco com usuários e cursos de teste
├── server.js                     # Inicialização e sincronização do Sequelize
└── package.json
```

---

## 🔄 Como as Camadas Estão Interligadas

```
[ Cliente HTTP / Postman ]
       │
       ▼ (1) Envia requisição (ex: POST /api/auth/login)
[ routes/auth.routes.js ]
       │
       ▼ (2) Repassa para a função correspondente
[ controllers/AuthController.js ]
       │
       ├─► (3) Usa bcrypt.compare(senha, hash)
       │
       ├─► (4) Chama diretamente o ORM: Usuario.findOne({ where: { email } })
       │         │
       │         ▼
       │   [ models/Usuario.js ] ──► [ Banco MySQL ]
       │
       └─► (5) Gera o Token: jwt.sign({ id, email, role }, secret)
       │
       ▼ (6) Devolve a resposta: res.status(200).json({ token, usuario })
[ Cliente HTTP ]
```

---

## ⚡ Como Executar

### 1. Instalar as dependências
```bash
cd "5.1. auth-jwt"
npm install
```

### 2. Rodar os Seeds (Criar tabelas e dados de teste)
```bash
npm run seed
```
> Usuários criados automaticamente:
> * **Administrador:** `admin@escola.com` | Senha: `admin123` *(role: admin)*
> * **Estudante:** `user@escola.com` | Senha: `user123` *(role: user)*

### 3. Iniciar o servidor em modo de desenvolvimento
```bash
npm run dev
```
Servidor rodará em: `http://localhost:3000`

---

## 🧪 Roteiro de Testes (cURL)

### 1. Registrar Novo Usuário (Público)
```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"nome": "Carlos Souza", "email": "carlos@escola.com", "senha": "senha123", "role": "user"}'
```

---

### 2. Fazer Login e Receber o Token JWT
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@escola.com", "senha": "admin123"}'
```
*Copie o token retornado no campo `"token"`.*

---

### 3. Acessar Rota Protegida (`/me`) com o Token
```bash
curl -X GET http://localhost:3000/api/auth/me \
  -H "Authorization: Bearer SEU_TOKEN_AQUI"
```

---

### 4. Listar Alunos (Exige Token)
```bash
curl -X GET http://localhost:3000/api/alunos \
  -H "Authorization: Bearer SEU_TOKEN_AQUI"
```

---

### 5. Cadastrar Aluno (Exige Token)
```bash
curl -X POST http://localhost:3000/api/alunos \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer SEU_TOKEN_AQUI" \
  -d '{"nome": "Mariana Lima", "email": "mariana@escola.com", "matricula": "MAT202610", "cursoId": 1}'
```

---

### 6. Excluir Aluno (Exige Perfil de Administrador `admin`)
Se você tentar excluir usando o token de um usuário comum (`user@escola.com`), a API devolverá **403 Forbidden**. Apenas com o token de `admin@escola.com` a exclusão será autorizada:
```bash
curl -X DELETE http://localhost:3000/api/alunos/1 \
  -H "Authorization: Bearer TOKEN_DO_ADMIN"
```
