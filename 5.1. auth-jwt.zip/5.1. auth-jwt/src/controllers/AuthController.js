const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Usuario } = require('../models');
const { jwtSecret, jwtExpiresIn } = require('../config/auth');

class AuthController {
    // POST /api/auth/register
    async registrar(req, res, next) {
        try {
            const { nome, email, senha, role } = req.body;

            // 1. Validações básicas de entrada
            if (!nome || !email || !senha) {
                return res.status(400).json({ erro: 'Nome, e-mail e senha são obrigatórios.' });
            }

            if (senha.length < 6) {
                return res.status(400).json({ erro: 'A senha deve ter no mínimo 6 caracteres.' });
            }

            // 2. Consulta direta com o Sequelize ORM: verifica se o e-mail já existe
            const usuarioExistente = await Usuario.findOne({ where: { email } });
            if (usuarioExistente) {
                return res.status(400).json({ erro: 'Este e-mail já está em uso.' });
            }

            // 3. Criptografa a senha antes de salvar no banco
            const senhaHash = await bcrypt.hash(senha, 10);

            // 4. Criação direta no banco com Sequelize ORM
            const novoUsuario = await Usuario.create({
                nome,
                email,
                senha: senhaHash,
                role: role || 'user'
            });

            return res.status(201).json({
                mensagem: 'Usuário cadastrado com sucesso!',
                usuario: {
                    id: novoUsuario.id,
                    nome: novoUsuario.nome,
                    email: novoUsuario.email,
                    role: novoUsuario.role
                }
            });
        } catch (error) {
            next(error);
        }
    }

    // POST /api/auth/login
    async login(req, res, next) {
        try {
            const { email, senha } = req.body;

            if (!email || !senha) {
                return res.status(400).json({ erro: 'E-mail e senha são obrigatórios.' });
            }

            // 1. Busca o usuário no banco pelo e-mail usando o Sequelize
            const usuario = await Usuario.findOne({ where: { email } });
            if (!usuario) {
                return res.status(401).json({ erro: 'Credenciais inválidas.' });
            }

            // 2. Compara a senha informada com o hash criptografado salvo no banco
            const senhaValida = await bcrypt.compare(senha, usuario.senha);
            if (!senhaValida) {
                return res.status(401).json({ erro: 'Credenciais inválidas.' });
            }

            // 3. Gera o Token JWT assinado com os dados do usuário
            const token = jwt.sign(
                {
                    id: usuario.id,
                    email: usuario.email,
                    role: usuario.role
                },
                jwtSecret,
                { expiresIn: jwtExpiresIn }
            );

            return res.status(200).json({
                mensagem: 'Login realizado com sucesso!',
                token,
                usuario: {
                    id: usuario.id,
                    nome: usuario.nome,
                    email: usuario.email,
                    role: usuario.role
                }
            });
        } catch (error) {
            next(error);
        }
    }

    // GET /api/auth/me (Rota protegida)
    async me(req, res) {
        // req.usuario foi preenchido pelo middleware de autenticação
        return res.status(200).json({
            mensagem: 'Sessão atual validada via Token JWT',
            usuario: req.usuario
        });
    }
}

module.exports = new AuthController();
