const express = require('express');
const router = express.Router();
const authController = require('../controllers/AuthController');
const { autenticar } = require('../middlewares/auth.middleware');

// Rotas públicas (não exigem token)
router.post('/register', (req, res, next) => authController.registrar(req, res, next));
router.post('/login', (req, res, next) => authController.login(req, res, next));

// Rota protegida (exige token no header Authorization: Bearer <token>)
router.get('/me', autenticar, (req, res) => authController.me(req, res));

module.exports = router;
