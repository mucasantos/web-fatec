const express = require('express');
const router = express.Router();
const alunoController = require('../controllers/AlunoController');
const { autenticar, autorizar } = require('../middlewares/auth.middleware');

// Todas as rotas de alunos exigem autenticação prévia via Token JWT
router.use(autenticar);

// Rotas liberadas para qualquer usuário autenticado (role 'user' ou 'admin')
router.get('/', (req, res, next) => alunoController.listar(req, res, next));
router.get('/:id', (req, res, next) => alunoController.buscarPorId(req, res, next));
router.post('/', (req, res, next) => alunoController.criar(req, res, next));
router.put('/:id', (req, res, next) => alunoController.atualizar(req, res, next));

// Rota restrita: apenas administradores (role 'admin') podem excluir
router.delete('/:id', autorizar('admin'), (req, res, next) => alunoController.excluir(req, res, next));

module.exports = router;
