module.exports = {
    jwtSecret: process.env.JWT_SECRET || 'chave_secreta_super_segura_fatec_2026',
    jwtExpiresIn: '2h'
};
