const jwt = require('jsonwebtoken');
const { jwtSecret } = require('../config/auth');

// Middleware para verificar se o usuário enviou um token JWT válido
const autenticar = (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
        return res.status(401).json({ erro: 'Token de autenticação não fornecido.' });
    }

    const [scheme, token] = authHeader.split(' ');

    if (scheme !== 'Bearer' || !token) {
        return res.status(401).json({ erro: 'Formato de token inválido. Use: Bearer <token>' });
    }

    try {
        const decoded = jwt.verify(token, jwtSecret);
        // Anexa os dados do usuário na requisição para uso nos controllers
        req.usuario = {
            id: decoded.id,
            email: decoded.email,
            role: decoded.role
        };
        return next();
    } catch (err) {
        if (err.name === 'TokenExpiredError') {
            return res.status(401).json({ erro: 'Token expirado. Por favor, faça login novamente.' });
        }
        return res.status(401).json({ erro: 'Token inválido ou adulterado.' });
    }
};

// Middleware para autorização baseada em papéis (ex: 'admin', 'user')
const autorizar = (...rolesPermitidas) => {
    return (req, res, next) => {
        if (!req.usuario) {
            return res.status(401).json({ erro: 'Usuário não autenticado.' });
        }

        if (!rolesPermitidas.includes(req.usuario.role)) {
            return res.status(403).json({
                erro: `Acesso negado. Ação permitida apenas para o(s) perfil(is): [${rolesPermitidas.join(', ')}].`
            });
        }

        return next();
    };
};

module.exports = {
    autenticar,
    autorizar
};
